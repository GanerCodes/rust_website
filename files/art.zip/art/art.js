function rb() {
    return random(0, 1) >= 0.5;
}

var s = 100;
let locList = {};
let limit = 10;
var blob;

var clrs = [
    [255, 0  , 0  ],
    [0  , 255, 0  ],
    [0  , 0  , 255],
    [255, 255, 0  ],
    [255, 0  , 255],
    [0  , 255, 255]
];

function mod(n, m) { //because JS is s p e c i a l
    return ((n % m) + m) % m;
}

function makeShape(r, x, y, seed, limit, f, pq) {
    randomSeed(seed);
    
    let c1 = clrs[Math.floor(random(0, clrs.length))];
    let c2 = clrs[Math.floor(random(0, clrs.length))];
    let c3 = clrs[Math.floor(random(0, clrs.length))];
    
    if(pq == undefined) {
        pq = [false, false, false, false];
    }
    if(x in locList) {
        if(locList[x].includes(y)) {
            return;
        }else{
            locList[x].push(y);
        }
    }else{
        locList[x] = [y];
    }
    // console.log(x, y, f, pq);
    let d = 1;
    let p = 1;
    let coords = [
        L  = [-d,  0], // L
        BL = [-p,  p], // BL
        B  = [ 0,  d], // B
        BR = [ p,  p], // BR
        R  = [ d,  0], // R
        TR = [ p, -p], // TR
        T  = [ 0, -d], // T
        TL = [-p, -p], // TL
    ]
    let q = [
        (!pq[0] && rb()),
        (!pq[1] && rb()),
        (!pq[2] && rb()),
        (!pq[3] && rb())
    ];
    let mw = s / 2;
    let mh = s / 2;
    
    blob.clear();
    blob.rectMode(CENTER);
    blob.fill(f * 64, 255 - f * 64, 255);
    blob.noStroke();
    blob.beginShape();
    blob.vertex(mw * coords[0][0], mh * coords[0][1]);
    for(let i = 1; i < coords.length; i += 2) {
        if(q[floor(0.5 * (i - 1))]) {
            if(random(0, 1) > 0.3) {
                blob.quadraticVertex(
                    mw * coords[i % coords.length][0],
                    mh * coords[i % coords.length][1],
                    mw * coords[(i + 1) % coords.length][0],
                    mh * coords[(i + 1) % coords.length][1]
                );
            }
        }else{
            if(random(0, 1) > 0.1) {
                blob.vertex(
                    mw * coords[i % coords.length][0],
                    mh * coords[i % coords.length][1]
                );
            }
            if(random(0, 1) > 0.1) {
                blob.vertex(
                    mw * coords[(i + 1) % coords.length][0],
                    mh * coords[(i + 1) % coords.length][1]
                );
            }
        }
    }
    blob.endShape(CLOSE);
    
    let img = createImage(blob.width, blob.height);
    blob.loadPixels();
    img.loadPixels();
    
    let cond = Math.floor(random(0, 7));
    let hbw = blob.width  / 2 + random(-1, 1);
    let hbh = blob.height / 2 + random(-1, 1);
    let sx = 1.5 / blob.width ;
    let sy = 1.5 / blob.height;
    let ix = 0, iy = 0;
    let ax = 0, ay = 0, v = 0;
    let tempAng = random(0, TWO_PI);
    for(let i = 0; i < blob.pixels.length; i += 4) {
        if(blob.pixels[i + 1] > 20) {
            ax = sx * (ix - hbw);
            ay = sy * (iy - hbh);
            switch(cond) {
                case 0: {
                    v = Math.sin(5 * TWO_PI * Math.sqrt(pow(ax, 2) + pow(ay, 2)));
                } break;
                case 1: {
                    v = Math.sin(15 * ax) + Math.cos(15 * ay);
                } break;
                case 2: {
                    v = pow(Math.sin(12 * ax), 2) + pow(Math.cos(12 * ay), 2) - pow(0.8, 2);
                } break;
                case 3: {
                    v = sin(10 * Math.atan2(ay, ax));
                } break;
                case 4: {
                    v = cos(17 * (sin(tempAng) * ay - cos(tempAng) * ax));
                } break;
                case 5: {
                    let tx = mod(ax, 0.6) - 0.3;
                    let ty = mod(ay, 0.6) - 0.3;
                    v = abs(tx) + abs(ty) + max(abs(tx), abs(ty)) - 0.5;
                } break;
                case 6: {
                    v = cos(10 * ay) - 0.9 * sin(7 * ax);
                } break;
            }
            if(v <= 0) {
                img.pixels[i + 0] = c1[0];
                img.pixels[i + 1] = c1[1];
                img.pixels[i + 2] = c1[2];
                img.pixels[i + 3] = 255;
            }else{
                img.pixels[i + 0] = c2[0];
                img.pixels[i + 1] = c2[1];
                img.pixels[i + 2] = c2[2];
                img.pixels[i + 3] = 255;
            }
        }
        
        ix++;
        if(ix == blob.width) {
            ix = 0;
            iy++;
        }
    }
    img.updatePixels();
    
    r.push();
    r.translate(x, y);
    r.image(img, 0, 0);
    r.pop();
    if(limit > 0) {
        limit--;
        j = [];
        if(!(q[0] || q[1])) { j.push([-1,  0, 0]); }
        if(!(q[1] || q[2])) { j.push([ 0, -1, 1]); }
        if(!(q[2] || q[3])) { j.push([ 1,  0, 2]); }
        if(!(q[3] || q[0])) { j.push([ 0,  1, 3]); }
        for(let c of j) {
            let nX = x + c[0] * s;
            let nY = y + c[1] * s;
            makeShape(r, nX, nY, random(0, 100000000), limit, f + 1, [...q]);
        }
    }
    return q;
}

var seed;
var base, img;
function setup() {
    var cnv = createCanvas(2500, 1280, WEBGL);
    cnv.style('display', 'block');
    seed = random(1, 1000000000);
    randomSeed(seed);
    base = createGraphics(width, height, WEBGL);
    blob = createGraphics(100, 100, WEBGL);
    for(let i = 0; i < 14; i++) {
        let x1 = s * Math.floor(random(1/6*base.width , 5/6*base.width ) / s) -  width / 2;
        let y1 = s * Math.floor(random(1/6*base.height, 5/6*base.height) / s) - height / 2;
        makeShape(base, x1, y1, random(0, 100000000), 10, 0); //base.width / 2, base.height / 2
    }
    // img = createImage(base.width, base.height);
    // img.copy(base, 0, 0, base.width, base.height, 0, 0, base.width, base.height);
}
function draw() {
    background(8, 44, 74);
    strokeWeight(5);
    stroke(255);
    noFill();
    rectMode(CENTER);
    rect(0, 0, width, height);
    
    imageMode(CENTER);
    // image(img, 0, 0);
    image(base, 0, 0);
    // background(base);
    
    fill(255, 0, 0);
    noStroke();
    circle(0, 0, 5);
}
function keyPressed() {
    randomSeed(random(1, 1000000000));
    seed = random(1, 1000000000);
}